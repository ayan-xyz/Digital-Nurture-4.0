
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace SwaggerApiDemo.Controllers
{
    [ApiController]
    [Route("Emp")]
    public class EmployeeController : ControllerBase
    {
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "John", "Jane", "Mark" };
        }
    }
}
