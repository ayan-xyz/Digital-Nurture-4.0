using Microsoft.AspNetCore.Mvc;
using EmployeeWebApiProject.Models;
using EmployeeWebApiProject.Filters;
using System.Collections.Generic;
using System;
using Microsoft.AspNetCore.Http;

namespace EmployeeWebApiProject.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [CustomAuthFilter]
    public class EmployeeController : ControllerBase
    {
        private static List<Employee> _employeeList = new List<Employee>();

        public EmployeeController()
        {
            if (_employeeList.Count == 0)
            {
                _employeeList = GetStandardEmployeeList();
            }
        }

        private List<Employee> GetStandardEmployeeList()
        {
            return new List<Employee>
            {
                new Employee
                {
                    Id = 1,
                    Name = "John",
                    Salary = 50000,
                    Permanent = true,
                    Department = new Department { Id = 1, Name = "IT" },
                    Skills = new List<Skill>
                    {
                        new Skill { Id = 1, Name = "C#" },
                        new Skill { Id = 2, Name = "ASP.NET" }
                    },
                    DateOfBirth = new DateTime(1990, 5, 1)
                }
            };
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public ActionResult<List<Employee>> Get()
        {
            throw new Exception("Test exception for CustomExceptionFilter");
        }

        [HttpGet("standard")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public ActionResult<Employee> GetStandard()
        {
            return Ok(_employeeList[0]);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Employee employee)
        {
            _employeeList.Add(employee);
            return Ok();
        }

        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody] Employee employee)
        {
            var existing = _employeeList.Find(e => e.Id == id);
            if (existing == null) return NotFound();
            existing.Name = employee.Name;
            existing.Salary = employee.Salary;
            existing.Permanent = employee.Permanent;
            existing.Department = employee.Department;
            existing.Skills = employee.Skills;
            existing.DateOfBirth = employee.DateOfBirth;
            return Ok();
        }
    }
}